(function(){const J=/^(css-|sc-|s-|_|is-animat)|^[a-z]{1,3}-[a-f0-9]{5,}$|[a-f0-9]{8,}|^svelte-|^emotion-|^jsx-/i,z=["data-testid","data-test","data-cy","name","role","aria-label","href","type","title","placeholder","alt"];function f(t){return t.localName||t.tagName.toLowerCase()}function I(t){return t.replace(/\\/g,"\\\\").replace(/"/g,'\\"')}function j(t){return[...t.classList].filter(e=>!(!e||e.length>48||J.test(e)))}function h(t,e){try{return e.ownerDocument.querySelector(t)===e}catch{return!1}}function x(t,e){try{const n=e.ownerDocument.querySelectorAll(t);return n.length===1&&n[0]===e}catch{return!1}}function k(t){const e=t.getAttribute("id");if(!e)return null;const n=`#${CSS.escape(e)}`;return x(n,t)?n:null}function V(t){const e=f(t);for(const n of z){const r=t.getAttribute(n);if(!r||r.length>120)continue;const o=`${e}[${n}="${I(r)}"]`;if(x(o,t))return o}return null}function R(t){const e=j(t);if(!e.length)return null;const n=f(t);for(let o=e.length;o>=1;o--){const i=`${n}.${e.slice(0,o).map(CSS.escape).join(".")}`;if(x(i,t))return i}const r=`.${e.map(CSS.escape).join(".")}`;return x(r,t)?r:null}function _(t){const e=t.parentElement,n=f(t);if(!e)return n;const r=[...e.children].filter(o=>f(o)===n);return r.length===1?n:`${n}:nth-of-type(${r.indexOf(t)+1})`}function Q(t){let e=t.parentElement;for(;e;){const n=k(e);if(n){const r=j(t),o=f(t);if(r.length){for(let s=r.length;s>=1;s--){const u=`${n} ${o}.${r.slice(0,s).map(CSS.escape).join(".")}`;if(h(u,t))return u}const a=`${n} .${r.map(CSS.escape).join(".")}`;if(h(a,t))return a}for(const a of z){const s=t.getAttribute(a);if(!s||s.length>120)continue;const u=`${n} ${o}[${a}="${I(s)}"]`;if(h(u,t))return u}const i=`${n} ${_(t)}`;if(h(i,t))return i}e=e.parentElement}return null}function L(t){const e=[];let n=t;for(;n&&n.nodeType===1;){const r=k(n);if(r){e.unshift(r);break}const o=R(n);if(o&&n!==t){e.unshift(o);break}if(e.unshift(_(n)),f(n)==="html")break;n=n.parentElement}return e.join(" > ")}function Z(t){const e=[k(t),V(t),Q(t),R(t),L(t)].filter(n=>!!n);for(const n of e)if(h(n,t))return n;return L(t)}function tt(t){return`document.querySelector(${JSON.stringify(t)})`}function g(t){return t.localName||t.tagName.toLowerCase()}function O(t){return t.includes("'")?t.includes('"')?`concat(${t.split("'").map(e=>`'${e}'`).join(`, "'", `)})`:`"${t}"`:`'${t}'`}function M(t){const e=t.getAttribute("id");if(!e)return null;const n=`//*[@id=${O(e)}]`;return N(t,n)?n:null}function N(t,e){try{const n=t.ownerDocument.evaluate(e,t.ownerDocument,null,XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,null);return n.snapshotLength===1&&n.snapshotItem(0)===t}catch{return!1}}const et=["data-testid","data-test","data-cy","name","role","aria-label","href","type","title","placeholder","alt"];function nt(t){const e=g(t);for(const n of et){const r=t.getAttribute(n);if(!r||r.length>80)continue;const o=`//${e}[@${n}=${O(r)}]`;if(N(t,o))return o}return null}function ot(t){const e=t.parentElement;if(!e)return 1;const n=g(t);let r=0;for(const o of e.children)if(g(o)===n&&(r+=1),o===t)return r;return 1}function rt(t){const e=[];let n=t;for(;n&&n.nodeType===1;){const r=M(n);if(r){const u=e.join("/");return u?`${r}/${u}`:r}const o=g(n),i=ot(n),a=n.parentElement,s=!a||[...a.children].filter(u=>g(u)===o).length>1;if(e.unshift(s?`${o}[${i}]`:o),o==="html")break;n=n.parentElement}return"/"+e.join("/")}function it(t){const e=M(t);if(e)return e;const n=nt(t);return n||rt(t)}const at=["id","class","href","src","name","type","role","title"],st={Layout:["display","position","overflow","z-index"],Size:["width","height","min-width","max-width","min-height","max-height"],Spacing:["margin","padding","gap"],Typography:["font-family","font-size","font-weight","line-height","text-align"],Colors:["color","background-color"],Border:["border","border-radius"]},lt=new Set(["style","tabindex","contenteditable","draggable","spellcheck","hidden"]);function w(t){return t.localName||t.tagName.toLowerCase()}function ct(t){const e=(t.textContent??"").replace(/\s+/g," ").trim();return e.length<=160?e:`${e.slice(0,157)}...`}function P(t,e=160){return t.length<=e?t:`${t.slice(0,e-3)}...`}function ut(t){const e=t.trim();return e?!["auto","none","normal","visible","static","rgba(0, 0, 0, 0)"].includes(e):!1}function dt(t){const e=[],n=new Set;for(const o of at){if(o==="class"){t.classList.length&&(e.push({name:"class",value:[...t.classList].join(" ")}),n.add("class"));continue}if(o==="id"){const a=t.getAttribute("id");a&&(e.push({name:"id",value:a}),n.add("id"));continue}const i=t.getAttribute(o);i&&(e.push({name:o,value:P(i)}),n.add(o))}const r=[];for(const o of t.attributes)n.has(o.name)||lt.has(o.name)||!o.name.startsWith("aria-")&&!o.name.startsWith("data-")||!o.value||o.value.length>160||r.push({name:o.name,value:P(o.value)});return r.sort((o,i)=>o.name.localeCompare(i.name)),[...e,...r].slice(0,24)}function pt(t){try{const e=getComputedStyle(t);return Object.entries(st).map(([n,r])=>({name:n,items:r.map(o=>({property:o,value:e.getPropertyValue(o).trim()})).filter(o=>ut(o.value))})).filter(n=>n.items.length>0)}catch{return[]}}function ft(t){const e=t.getAttribute("id");if(e)return`#${e}`;const n=[...t.classList].slice(0,2);return n.length?`${w(t)}.${n.join(".")}`:w(t)}function B(t){const e=[];let n=t;for(;n&&w(n)!=="html";)e.unshift(n),n=n.parentElement;return e.slice(-10)}function mt(t){return B(t).map(e=>({label:ft(e)}))}function d(t){const e=t.getBoundingClientRect(),n=Z(t);return{tagName:w(t).toUpperCase(),id:t.getAttribute("id")??"",classes:[...t.classList],text:ct(t),width:Math.round(e.width),height:Math.round(e.height),selector:n,xpath:it(t),jsSelector:tt(n),html:t.outerHTML.length>4e3?`${t.outerHTML.slice(0,3997)}...`:t.outerHTML,attributes:dt(t),styles:pt(t),breadcrumb:mt(t)}}function c(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}async function b(t){try{await navigator.clipboard.writeText(t);return}catch{const e=document.createElement("textarea");e.value=t,e.setAttribute("readonly",""),e.style.position="fixed",e.style.left="-9999px",document.body.appendChild(e),e.select(),document.execCommand("copy"),e.remove()}}const S="__dompilot_host";function ht(){const t=document.getElementById(S);if(!(t!=null&&t.shadowRoot))return null;const e=t.shadowRoot;return{host:t,shadow:e,highlight:e.getElementById("highlight"),tooltip:e.getElementById("tooltip"),panel:e.getElementById("panel"),toast:e.getElementById("toast")}}function v(){const t=ht();if(t)return t;const e=document.createElement("div");e.id=S,e.setAttribute("data-dompilot","true"),e.style.all="initial",e.style.position="fixed",e.style.zIndex="2147483646",e.style.pointerEvents="none",e.style.inset="0";const n=e.attachShadow({mode:"open"});return n.innerHTML=`
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; }
      #highlight {
        position: fixed;
        pointer-events: none;
        border: 1px solid #5eb1ff;
        background: rgba(94, 177, 255, 0.14);
        outline: 1px solid rgba(0, 0, 0, 0.45);
        display: none;
      }
      #tooltip, #toast, #panel {
        font-family: ui-sans-serif, system-ui, Segoe UI, sans-serif;
        color: #e8eaed;
      }
      #tooltip {
        position: fixed;
        display: none;
        pointer-events: none;
        background: #111318;
        border: 1px solid #2a2f3a;
        padding: 4px 7px;
        font-size: 11px;
        line-height: 1.35;
        max-width: 320px;
        z-index: 2;
      }
      #tooltip .tag { color: #5eb1ff; font-family: ui-monospace, SFMono-Regular, Consolas, monospace; }
      #tooltip .meta { color: #9aa3b2; }
      #toast {
        position: fixed;
        top: 16px;
        left: 50%;
        transform: translateX(-50%);
        background: #111318;
        border: 1px solid #2f6f4a;
        color: #b6f0c8;
        padding: 6px 10px;
        font-size: 12px;
        display: none;
        z-index: 4;
        pointer-events: none;
      }
      #panel {
        position: fixed;
        right: 12px;
        bottom: 12px;
        width: 340px;
        max-height: min(78vh, 560px);
        background: #0f1218;
        border: 1px solid #2a2f3a;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.45);
        display: none;
        pointer-events: auto;
        z-index: 3;
        overflow: hidden;
      }
      #panel header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 8px 10px;
        border-bottom: 1px solid #2a2f3a;
        font-size: 12px;
      }
      #panel header strong { font-weight: 650; letter-spacing: 0.01em; }
      .panel-scroll {
        max-height: calc(min(78vh, 560px) - 36px);
        overflow: auto;
      }
      button {
        appearance: none;
        background: #1a2030;
        color: #d7dce5;
        border: 1px solid #323846;
        font: inherit;
        font-size: 11px;
        padding: 3px 7px;
        cursor: pointer;
      }
      button:hover { border-color: #5eb1ff; color: #fff; }
      button.close {
        width: 22px;
        height: 22px;
        padding: 0;
        line-height: 1;
        font-size: 16px;
      }
      .block {
        padding: 8px 10px;
        border-bottom: 1px solid #1c212b;
      }
      .label {
        color: #8b93a2;
        font-size: 10px;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        margin-bottom: 4px;
      }
      .value {
        font-size: 12px;
        word-break: break-word;
      }
      .mono {
        font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
        font-size: 11px;
        color: #d2d8e2;
        overflow-wrap: anywhere;
      }
      .element-title { font-size: 13px; color: #5eb1ff; }
      .sub { margin-top: 2px; color: #9aa3b2; }
      .selector-block {
        margin-top: 6px;
        padding: 6px;
        background: #121722;
        border: 1px solid #1f2531;
      }
      .selector-label {
        color: #8b93a2;
        font-size: 10px;
        text-transform: uppercase;
        margin-bottom: 3px;
      }
      .selector-block button { margin-top: 6px; }
      .actions {
        display: flex;
        gap: 6px;
        margin-top: 8px;
      }
      .actions button { flex: 1; padding: 6px 8px; }
      .section {
        border-bottom: 1px solid #1c212b;
      }
      .section summary {
        list-style: none;
        cursor: pointer;
        padding: 8px 10px;
        color: #8b93a2;
        font-size: 10px;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        user-select: none;
      }
      .section summary::-webkit-details-marker { display: none; }
      .section summary::after {
        content: "▶";
        float: right;
        color: #6d7482;
        font-size: 9px;
      }
      .section[open] summary::after { content: "▼"; }
      .section-body { padding: 0 10px 8px; }
      .muted { color: #6d7482; font-size: 11px; margin: 0; }
      .attr-row { margin-bottom: 6px; }
      .attr-name { color: #8b93a2; font-size: 10px; text-transform: lowercase; }
      .attr-value { font-size: 11px; word-break: break-word; }
      .style-group { margin-bottom: 8px; }
      .style-group-name {
        color: #8b93a2;
        font-size: 10px;
        text-transform: uppercase;
        margin-bottom: 4px;
      }
      .style-row {
        display: grid;
        grid-template-columns: 92px 1fr;
        gap: 6px;
        font-size: 11px;
        margin-bottom: 3px;
      }
      .style-value { word-break: break-word; color: #d2d8e2; }
      .crumb-row {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 4px;
      }
      .crumb {
        padding: 2px 6px;
        font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
        font-size: 10px;
      }
      .crumb-sep { color: #6d7482; font-size: 10px; }
    </style>
    <div id="highlight"></div>
    <div id="tooltip"></div>
    <div id="panel"></div>
    <div id="toast"></div>
  `,document.documentElement.appendChild(e),{host:e,shadow:n,highlight:n.getElementById("highlight"),tooltip:n.getElementById("tooltip"),panel:n.getElementById("panel"),toast:n.getElementById("toast")}}function D(){var t;(t=document.getElementById(S))==null||t.remove()}function H(t){return t.composedPath().some(n=>n instanceof Element&&n.id===S)}function T(t,e){const n=t.getBoundingClientRect();e.style.display="block",e.style.top=`${n.top}px`,e.style.left=`${n.left}px`,e.style.width=`${Math.max(n.width,1)}px`,e.style.height=`${Math.max(n.height,1)}px`}function X(t,e,n){const r=t.getBoundingClientRect();e.innerHTML=n,e.style.display="block";const o=r.top>36?r.top-30:r.bottom+6;let i=r.left;e.style.top=`${o}px`,e.style.left=`${i}px`;const a=e.getBoundingClientRect();a.right>window.innerWidth-8&&(i=Math.max(8,window.innerWidth-a.width-8),e.style.left=`${i}px`)}let A=0;function y(t){const e=v();e.toast.textContent=t,e.toast.style.display="block",window.clearTimeout(A),A=window.setTimeout(()=>{e.toast.style.display="none",e.panel.style.display==="block"||e.highlight.style.display==="block"||D()},1600)}function E(t,e,n=!0){return`
    <details class="section" ${n?"open":""}>
      <summary>${c(t)}</summary>
      <div class="section-body">${e}</div>
    </details>
  `}function gt(t){return t.attributes.length?t.attributes.map(e=>`
        <div class="attr-row">
          <div class="attr-name mono">${c(e.name)}</div>
          <div class="attr-value">${c(e.value)}</div>
        </div>
      `).join(""):'<p class="muted">No useful attributes.</p>'}function bt(t){return t.styles.length?t.styles.map(e=>`
        <div class="style-group">
          <div class="style-group-name">${c(e.name)}</div>
          ${e.items.map(n=>`
                <div class="style-row">
                  <span class="mono">${c(n.property)}</span>
                  <span class="style-value">${c(n.value)}</span>
                </div>
              `).join("")}
        </div>
      `).join(""):'<p class="muted">No computed styles available.</p>'}function yt(t){return t.breadcrumb.length?`
    <div class="crumb-row">
      ${t.breadcrumb.map((e,n)=>`
            <button type="button" class="crumb" data-crumb="${n}">${c(e.label)}</button>
          `).join('<span class="crumb-sep">›</span>')}
    </div>
  `:'<p class="muted">No DOM path available.</p>'}function vt(t,e){t.querySelectorAll("[data-copy]").forEach(n=>{n.addEventListener("click",async r=>{r.preventDefault(),r.stopPropagation();const o=n.dataset.copy??"",i=d(e),s={selector:{value:i.selector,label:"CSS selector copied"},xpath:{value:i.xpath,label:"XPath copied"},js:{value:i.jsSelector,label:"JavaScript selector copied"},html:{value:e.outerHTML,label:"HTML copied"},text:{value:i.text,label:"Text copied"},attributes:{value:i.attributes.map(u=>`${u.name}=${u.value}`).join(`
`),label:"Attributes copied"}}[o];s!=null&&s.value&&(await b(s.value),y(`✓ ${s.label}`))})})}function xt(t,e,n){const r=B(e);t.querySelectorAll("[data-crumb]").forEach(o=>{o.addEventListener("click",i=>{i.preventDefault(),i.stopPropagation();const a=Number(o.dataset.crumb),s=r[a];s&&n(s)})})}function wt(t,e,n,r){var i;const o=d(e);t.panel.style.display="block",t.panel.innerHTML=`
    <header>
      <strong>DOMPilot</strong>
      <button type="button" class="close" data-close aria-label="Close">×</button>
    </header>
    <div class="panel-scroll">
      <div class="block">
        <div class="label">Element</div>
        <div class="value mono element-title">${c(o.tagName)}</div>
        ${o.id||o.classes.length?`<div class="value mono sub">${c([o.id?`#${o.id}`:"",o.classes.length?`.${o.classes.join(".")}`:""].filter(Boolean).join(" "))}</div>`:""}
      </div>

      <div class="block">
        <div class="label">Content</div>
        <div class="value">${o.text?c(o.text):"—"}</div>
      </div>

      <div class="block">
        <div class="label">Size</div>
        <div class="value mono">${o.width} × ${o.height}</div>
      </div>

      <div class="block">
        <div class="label">Selectors</div>
        <div class="selector-block">
          <div class="selector-label">CSS</div>
          <div class="value mono">${c(o.selector)}</div>
          <button type="button" data-copy="selector">Copy CSS</button>
        </div>
        <div class="selector-block">
          <div class="selector-label">XPath</div>
          <div class="value mono">${c(o.xpath)}</div>
          <button type="button" data-copy="xpath">Copy XPath</button>
        </div>
        <div class="actions">
          <button type="button" data-copy="js">Copy JS</button>
          <button type="button" data-copy="html">Copy HTML</button>
        </div>
      </div>

      ${E("Styles",bt(o),!1)}
      ${E("Attributes",gt(o),!1)}
      ${E("DOM Path",yt(o),!1)}
    </div>
  `,(i=t.panel.querySelector("[data-close]"))==null||i.addEventListener("click",a=>{a.preventDefault(),a.stopPropagation(),n()}),vt(t.panel,e),xt(t.panel,e,r)}const $t="__dompilot_host";let l=null,p=null;function St(t){p=t}function q(){return!p||!p.isConnected?null:p}function U(t,e){const n=document.elementsFromPoint(t,e);for(const r of n)if(r.id!==$t&&r instanceof Element)return r;return null}function F(t){const e=d(t),n=e.id?`#${e.id}`:"",r=e.classes.length?`.${e.classes.slice(0,3).join(".")}`:"";return`<span class="tag">${c(e.tagName.toLowerCase())}${c(n)}</span>
    <span class="meta"> ${c(r)} · ${e.width}×${e.height}</span>`}function C(t){if(!l)return;p=t,l.selected=t,l.hovered=t;const e=v();e.tooltip.style.display="none",T(t,e.highlight),wt(e,t,m,C)}function Y(t){if(!l||l.selected||H(t))return;const e=U(t.clientX,t.clientY);if(!e||e===l.hovered)return;l.hovered=e;const n=v();T(e,n.highlight),X(e,n.tooltip,F(e))}async function K(t){if(!l||H(t))return;const e=U(t.clientX,t.clientY);if(e){if(t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation(),p=e,l.hovered=e,l.mode==="copy-selector"){await b(d(e).selector),m(),y("✓ CSS selector copied");return}if(l.mode==="copy-xpath"){await b(d(e).xpath),m(),y("✓ XPath copied");return}C(e)}}function W(t){t.key==="Escape"&&(t.preventDefault(),m())}function $(){if(!l)return;const t=l.selected??l.hovered;if(!t)return;const e=v();T(t,e.highlight),l.selected||X(t,e.tooltip,F(t))}function G(t){m(),l={mode:t,hovered:null,selected:null},v(),document.addEventListener("mousemove",Y,!0),document.addEventListener("click",K,!0),document.addEventListener("keydown",W,!0),window.addEventListener("scroll",$,!0),window.addEventListener("resize",$,!0)}function Et(t){p=t,G("inspect"),C(t)}function m(){document.removeEventListener("mousemove",Y,!0),document.removeEventListener("click",K,!0),document.removeEventListener("keydown",W,!0),window.removeEventListener("scroll",$,!0),window.removeEventListener("resize",$,!0),l=null,D()}function kt(){const t=q();return t?d(t):null}document.addEventListener("contextmenu",t=>{t.target instanceof Element&&St(t.target)},!0);async function Tt(t){if(t.type==="PING")return{ok:!0};if(t.type==="START_PICKER")return G(t.mode),{ok:!0};if(t.type==="STOP_PICKER")return m(),{ok:!0};if(t.type==="GET_SNAPSHOT")return{ok:!0,snapshot:kt()};const e=q();if(!e)return{ok:!1,error:"Right-click an element on this page first."};if(t.type==="COPY_SELECTOR"){const n=d(e).selector;return await b(n),y("✓ CSS selector copied"),{ok:!0,copied:n}}if(t.type==="COPY_XPATH"){const n=d(e).xpath;return await b(n),y("✓ XPath copied"),{ok:!0,copied:n}}return t.type==="INSPECT_LAST"?(Et(e),{ok:!0,snapshot:d(e)}):{ok:!1,error:"Unknown message."}}chrome.runtime.onMessage.addListener((t,e,n)=>(Tt(t).then(n),!0));
})()
